﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using dip.Models;

namespace dip.Controllers
{
    public class HomeController : Controller
    {
        MyConfig _config;
        public HomeController(MyConfig config)
        {
            this._config = config;
        }
        [Route("index")]
        [Route("~/")]
        public IActionResult Index([FromServices] IFoo foo)
        {
            ViewBag.AppName = this._config.AppName;
            ViewBag.FromServices = foo.GetFoo();
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
