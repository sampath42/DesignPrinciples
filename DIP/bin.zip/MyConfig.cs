namespace dip
{
    public class MyConfig
    {
        public string AppName { get; set; }
    }
}